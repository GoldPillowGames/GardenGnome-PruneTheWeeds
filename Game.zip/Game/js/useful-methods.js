export default class UsefulMethods {
    static vectorModule(x, y) {
        return Math.sqrt(Math.pow(x, 2) + Math.pow(y, 2));
    }
}